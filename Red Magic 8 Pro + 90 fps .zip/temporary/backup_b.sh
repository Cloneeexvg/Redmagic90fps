#Technical Mundeer

# !/sbin/sh

busybox mount /sys

# Backup Original Battery Config

if [ ! -f /proc/sys/net/core/default_qdisc.partc ]; then
  cp /proc/sys/net/core/default_qdisc /proc/sys/net/core/default_qdisc.partc
fi

if [ ! -f /proc/sys/net/ipv4/tcp_congestion_control.partc ]; then
  cp /proc/sys/net/ipv4/tcp_congestion_control /proc/sys/net/ipv4/tcp_congestion_control.partc
fi
